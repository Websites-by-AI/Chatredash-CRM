import { useState } from "react";
import { 
  GraduationCap, LogOut, LayoutDashboard, FileSpreadsheet, 
  Calendar, MessageSquare, LineChart, Users, BellRing, Sparkles 
} from "lucide-react";
import { Student } from "./types";
import LoginView from "./components/LoginView";
import DashboardView from "./components/DashboardView";
import ReportCardView from "./components/ReportCardView";
import StudyPlanView from "./components/StudyPlanView";
import CounselorView from "./components/CounselorView";
import ProgressView from "./components/ProgressView";
import ParentsView from "./components/ParentsView";
import AdminView from "./components/AdminView";

export default function App() {
  const [student, setStudent] = useState<Student | null>(null);
  const [role, setRole] = useState<"student" | "parent" | "admin" | null>(null);
  const [view, setView] = useState<string>("dashboard");

  const handleLogin = (matchedStudent: Student, selectedRole: "student" | "parent" | "admin") => {
    setStudent(matchedStudent);
    setRole(selectedRole);
    if (selectedRole === "parent") {
      setView("parents");
    } else if (selectedRole === "admin") {
      setView("admin");
    } else {
      setView("dashboard");
    }
  };

  const handleLogout = () => {
    setStudent(null);
    setRole(null);
    setView("dashboard");
  };

  if (!role || !student) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col justify-between" id="app-auth-wrapper">
        <main className="flex-grow flex items-center justify-center py-10">
          <LoginView onLogin={handleLogin} />
        </main>
        <footer className="py-6 border-t border-slate-100 bg-white text-center text-xs text-slate-400">
          <div>© ترنم مهر | سامانه شخصی‌سازی آموزش و مشاوره تحصیلی با هوش مصنوعی</div>
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50/50 flex flex-col justify-between" id="app-dashboard-wrapper">
      {/* Prime Navigation Header */}
      <header className="bg-white border-b border-slate-100 sticky top-0 z-50 shadow-sm" id="app-master-header">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            {/* Left side: Logo & Branding */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-tr from-blue-900 to-indigo-950 text-white rounded-xl shadow-md flex items-center justify-center">
                <GraduationCap size={22} className="text-amber-400" />
              </div>
              <div>
                <span className="font-black text-slate-800 text-base block leading-none">ترنم مهر</span>
                <span className="text-[10px] text-blue-900 font-bold block mt-1 flex items-center gap-0.5">
                  <Sparkles size={8} />
                  <span>سامانه هوشمند آموزشی</span>
                </span>
              </div>
            </div>

            {/* Middle: Active Navigation tabs */}
            <nav className="hidden lg:flex gap-1" id="desktop-navbar">
              {role === "student" && (
                <>
                  <button
                    onClick={() => setView("dashboard")}
                    className={`flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-xl transition cursor-pointer ${
                      view === "dashboard" ? "bg-slate-100 text-blue-900" : "text-slate-500 hover:text-slate-700 hover:bg-slate-50/50"
                    }`}
                  >
                    <LayoutDashboard size={14} />
                    <span>داشبورد من</span>
                  </button>
                  <button
                    onClick={() => setView("report")}
                    className={`flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-xl transition cursor-pointer ${
                      view === "report" ? "bg-slate-100 text-blue-900" : "text-slate-500 hover:text-slate-700 hover:bg-slate-50/50"
                    }`}
                  >
                    <FileSpreadsheet size={14} />
                    <span>کارنامه هوشمند</span>
                  </button>
                  <button
                    onClick={() => setView("schedule")}
                    className={`flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-xl transition cursor-pointer ${
                      view === "schedule" ? "bg-slate-100 text-blue-900" : "text-slate-500 hover:text-slate-700 hover:bg-slate-50/50"
                    }`}
                  >
                    <Calendar size={14} />
                    <span>برنامه‌ریزی AI</span>
                  </button>
                  <button
                    onClick={() => setView("counselor")}
                    className={`flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-xl transition cursor-pointer ${
                      view === "counselor" ? "bg-slate-100 text-blue-900" : "text-slate-500 hover:text-slate-700 hover:bg-slate-50/50"
                    }`}
                  >
                    <MessageSquare size={14} />
                    <span>مشاور هوشمند</span>
                  </button>
                  <button
                    onClick={() => setView("progress")}
                    className={`flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-xl transition cursor-pointer ${
                      view === "progress" ? "bg-slate-100 text-blue-900" : "text-slate-500 hover:text-slate-700 hover:bg-slate-50/50"
                    }`}
                  >
                    <LineChart size={14} />
                    <span>نمودار رشد و پیشرفت</span>
                  </button>
                </>
              )}

              {role === "parent" && (
                <>
                  <button
                    onClick={() => setView("parents")}
                    className={`flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-xl transition cursor-pointer ${
                      view === "parents" ? "bg-slate-100 text-blue-900" : "text-slate-500 hover:text-slate-700 hover:bg-slate-50/50"
                    }`}
                  >
                    <BellRing size={14} />
                    <span>داشبورد والدین</span>
                  </button>
                  <button
                    onClick={() => setView("report")}
                    className={`flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-xl transition cursor-pointer ${
                      view === "report" ? "bg-slate-100 text-blue-900" : "text-slate-500 hover:text-slate-700 hover:bg-slate-50/50"
                    }`}
                  >
                    <FileSpreadsheet size={14} />
                    <span>کارنامه فرزند</span>
                  </button>
                </>
              )}

              {role === "admin" && (
                <>
                  <button
                    onClick={() => setView("admin")}
                    className={`flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-xl transition cursor-pointer ${
                      view === "admin" ? "bg-slate-100 text-blue-900" : "text-slate-500 hover:text-slate-700 hover:bg-slate-50/50"
                    }`}
                  >
                    <Users size={14} />
                    <span>پنل مدیریت ارشد</span>
                  </button>
                </>
              )}
            </nav>

            {/* Right side: User Profile & Logout */}
            <div className="flex items-center gap-4">
              <div className="text-left hidden md:block">
                <span className="font-bold text-slate-800 text-xs block text-right">{student.name}</span>
                <span className="text-[10px] text-slate-400 font-bold block text-right mt-0.5">
                  {role === "student" && `دانش‌آموز پایه ${student.grade}`}
                  {role === "parent" && "پنل والدین مستقل"}
                  {role === "admin" && "مدیر ارشد موسسه"}
                </span>
              </div>
              <button
                onClick={handleLogout}
                className="p-2 bg-slate-50 hover:bg-red-50 text-slate-500 hover:text-red-700 transition rounded-xl border border-slate-100 hover:border-red-100 cursor-pointer"
                title="خروج از سامانه"
                id="btn-nav-logout"
              >
                <LogOut size={18} />
              </button>
            </div>
          </div>

          {/* Mobile Tab Navigation bar */}
          <div className="flex lg:hidden overflow-x-auto pb-3 gap-1.5 scrollbar-none" id="mobile-navbar">
            {role === "student" && (
              <>
                <button
                  onClick={() => setView("dashboard")}
                  className={`px-3.5 py-2 text-[11px] font-bold rounded-lg transition whitespace-nowrap cursor-pointer ${
                    view === "dashboard" ? "bg-blue-900 text-white" : "text-slate-500 bg-slate-50"
                  }`}
                >
                  داشبورد دفتری
                </button>
                <button
                  onClick={() => setView("report")}
                  className={`px-3.5 py-2 text-[11px] font-bold rounded-lg transition whitespace-nowrap cursor-pointer ${
                    view === "report" ? "bg-blue-900 text-white" : "text-slate-500 bg-slate-50"
                  }`}
                >
                  کارنامه هوشمند
                </button>
                <button
                  onClick={() => setView("schedule")}
                  className={`px-3.5 py-2 text-[11px] font-bold rounded-lg transition whitespace-nowrap cursor-pointer ${
                    view === "schedule" ? "bg-blue-900 text-white" : "text-slate-500 bg-slate-50"
                  }`}
                >
                  برنامه AI
                </button>
                <button
                  onClick={() => setView("counselor")}
                  className={`px-3.5 py-2 text-[11px] font-bold rounded-lg transition whitespace-nowrap cursor-pointer ${
                    view === "counselor" ? "bg-blue-900 text-white" : "text-slate-500 bg-slate-50"
                  }`}
                >
                  مشاور
                </button>
                <button
                  onClick={() => setView("progress")}
                  className={`px-3.5 py-2 text-[11px] font-bold rounded-lg transition whitespace-nowrap cursor-pointer ${
                    view === "progress" ? "bg-blue-900 text-white" : "text-slate-500 bg-slate-50"
                  }`}
                >
                  پیشرفت صعودی
                </button>
              </>
            )}

            {role === "parent" && (
              <>
                <button
                  onClick={() => setView("parents")}
                  className={`px-3.5 py-2 text-[11px] font-bold rounded-lg transition whitespace-nowrap cursor-pointer ${
                    view === "parents" ? "bg-blue-900 text-white" : "text-slate-500 bg-slate-50"
                  }`}
                >
                  هشدارهای والدین
                </button>
                <button
                  onClick={() => setView("report")}
                  className={`px-3.5 py-2 text-[11px] font-bold rounded-lg transition whitespace-nowrap cursor-pointer ${
                    view === "report" ? "bg-blue-900 text-white" : "text-slate-500 bg-slate-50"
                  }`}
                >
                  تحلیل کارنامه فرزند
                </button>
              </>
            )}

            {role === "admin" && (
              <>
                <button
                  onClick={() => setView("admin")}
                  className={`px-3.5 py-2 text-[11px] font-bold rounded-lg transition whitespace-nowrap cursor-pointer ${
                    view === "admin" ? "bg-blue-900 text-white" : "text-slate-500 bg-slate-50"
                  }`}
                >
                  مدیریت و آپلودر قلمچی
                </button>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Main View Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-grow w-full" id="main-content-layout">
        {role === "student" && (
          <>
            {view === "dashboard" && <DashboardView student={student} onNavigate={(target) => setView(target)} />}
            {view === "report" && <ReportCardView student={student} />}
            {view === "schedule" && <StudyPlanView />}
            {view === "counselor" && <CounselorView student={student} />}
            {view === "progress" && <ProgressView />}
          </>
        )}

        {role === "parent" && (
          <>
            {view === "parents" && <ParentsView student={student} />}
            {view === "report" && <ReportCardView student={student} />}
          </>
        )}

        {role === "admin" && (
          <>
            {view === "admin" && <AdminView />}
          </>
        )}
      </main>

      {/* Persistent Footer */}
      <footer className="bg-white border-t border-slate-100 py-6 text-center text-xs text-slate-400 mt-10">
        <div>پلتفرم هوشمند آموزشی و برنامه‌ریزی درسی ترنم مهر بر اساس مدل ارزیابی کانون قلم‌چی • کپی‌رایت ۱۴۰۵</div>
      </footer>
    </div>
  );
}
