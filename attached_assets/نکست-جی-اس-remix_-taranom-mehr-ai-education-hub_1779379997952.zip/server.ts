import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";
import { createServer as createViteServer } from "vite";

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini SDK Client
let aiClient: GoogleGenAI | null = null;
function getAI() {
  try {
    if (!aiClient) {
      const key = process.env.GEMINI_API_KEY;
      if (!key || key.trim() === "" || key === "undefined" || key === "null") {
        console.warn("GEMINI_API_KEY is not defined or invalid. Using local simulation engine for AI responses.");
        return null;
      }
      aiClient = new GoogleGenAI({
        apiKey: key
      });
    }
    return aiClient;
  } catch (err) {
    console.error("Failed to initialize GoogleGenAI:", err);
    return null;
  }
}

// REST Api endpoints
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

// Endpoint for motivational messages
app.get("/api/motivational", async (req, res) => {
  try {
    const ai = getAI();
    const quotes = [
      "سودای بزرگی در سر داری و مسیر هم پر از فراز و نشیب است. امروز با هر قدم کوچکت به رویایت نزدیک‌تر می‌شوی. محکم ادامه بده!",
      "موفقیت به معنای بی‌نقص بودن نیست؛ بلکه ادامه دادن با وجود خستگی‌هاست. امروز بهترین نسخه کار خودت را به نمایش بگذار عزیزم!",
      "هر تست و تحلیل کارنامه‌ای، چراغی روبه‌جلوست. تلاش امروز تو، ترازِ درخشان فرداست. پر انرژی و پرتوان باش!",
      "یادت نره سختی‌های مسیر، تورو قوی‌تر میکنه. تو توانایی گذشتن از این کنکور لعنتی رو با نتایج فوق‌العاده داری. شروع کن!",
      "آرام آرام، اما با استواری کامل پیش برو. کوه‌ها حاصل ایستادگی ذره‌ها هستند. همین امروز یک آجر دیگه روی اهدافت بذار."
    ];

    if (!ai || !ai.models || typeof ai.models.generateContent !== "function") {
      const randomIndex = Math.floor(Math.random() * quotes.length);
      return res.json({ quote: quotes[randomIndex] });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: "یک پیام انگیزشی صمیمی، دلسوزانه و الهام‌بخش کوتاه (حداکثر دو جمله کوتاه) به زبان فارسی تفصیلی برای دانش‌آموز سخت‌کوشی که برای کنکور درس می‌خواند بدون هیچ نماد اضافه یا توضیح دیگر بنویس.",
    });
    return res.json({ quote: response.text?.trim() || quotes[Math.floor(Math.random() * quotes.length)] });
  } catch (error: any) {
    console.error("Error generating motivational quote:", error);
    const quotes = [
      "هر قدم کوچکی که امروز برمی‌داری، پلی خواهد شد برای فرداهای روشن‌تر غرق در موفقیت پیش برو!"
    ];
    res.json({ quote: quotes[0] });
  }
});

// Endpoint for academic coaching messages
app.post("/api/chat", async (req, res) => {
  try {
    const { message, history } = req.body;
    const ai = getAI();

    if (!ai || !ai.models || typeof ai.models.generateContent !== "function") {
      // Elegant local simulation counselor with rules
      const lowerMessage = (message || "").toString().toLowerCase();
      let reply = "";
      if (lowerMessage.includes("حرکت") || lowerMessage.includes("فیزیک")) {
        reply = "سلام قهرمان من! فیزیک و مبحث حرکت‌شناسی به خاطر فرمول‌های شتاب و فرمول مستقل از زمان نیاز به تجسم هندسی نمودار سرعت-زمان داره. پیشنهاد می‌کنم به جای حل ریاضی، ۵ تا تست اول رو بدون نوشتن مجهول صِرفاً نمودارش رو رسم کنی تا چشمت عادت کنه. چطور پیش میره این استراتژی برات؟";
      } else if (lowerMessage.includes("حد") || lowerMessage.includes("ریاضی")) {
        reply = "سلام عزیزم! مبحث حد و پیوستگی توی ریاضی کنکور خیلی تیپیکال و روتینه. بیشترین چالش بچه‌ها رفع ابهام صفر صفرمه که با هوپیتال یا ترفند اتحادها سریع حل میشه. از کتاب کار ترنم، بخش حد و پیوستگی رو باز کن و فرمول هم‌ارزی‌ها رو جداگونه یادداشت کن. امروز تمرین می‌کنی روش؟";
      } else if (lowerMessage.includes("سنگین") || lowerMessage.includes("خسته") || lowerMessage.includes("انگیزه")) {
        reply = "کاملاً حِسِت رو درک می‌کنم جانم. سال کنکور فراز و نشیب زیاد داره. این روزها دقیقاً همون جاهایی هستش که فاصله بین رتبه‌های برتر و بقیه مشخص میشه. تکنیک پومودورو رو پیاده کن (۲۵ دقیقه درس، ۵ دقیقه استراحت تفریحی). الان با یه استراحت کوتاه ۱۰ دقیقه‌ای موافقی تا پرانرژی برگردی؟";
      } else {
        reply = "چه سوال به‌جایی پرسیدی! برای اینکه دقیق بتونم راهنمایی‌ت کنم، اول برام بنویس چقدر زمان مطالعه‌ت منظم هست و در آزمون‌های قبلی درصد حدودی‌ت چقدر بوده؟ به عنوان مشاور اختصاصی‌ت توی موسسه ترنم مهر، همراهتم تا گام‌به‌گام برطرفش کنیم.";
      }
      return res.json({ reply });
    }

    // Map history elements into Gemini parts format
    const formattedHistory = (history || []).map((msg: any) => ({
      role: msg.role === "user" ? "user" : "model",
      parts: [{ text: msg.content }]
    }));

    formattedHistory.unshift({
      role: "user",
      parts: [{ text: "سیستم مشخصات: شما رتبه برتر و مشاور ارشد تحصیلی موسسه آموزشی 'ترنم مهر' هستید. نام شما 'آقای رادان' است. به زبان فارسی شیوا، صمیمی، دلسوزانه و فوق‌العاده کاربردی پاسخ دهید. دانش‌آموزان به شما اعتماد بالایی دارند؛ بنابراین راهکارهای تکنیکی، معرفی صفحات جزوه فرضی، و انگیزه دادن جزو وظایف شماست. پاسخ‌ها خلاصه (زیر ۳ پاراگراف) باشند." }]
    });

    formattedHistory.push({
      role: "user",
      parts: [{ text: message }]
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: formattedHistory,
    });

    return res.json({ reply: response.text?.trim() || "سوالی که مطرح کردی خیلی عالیه. در اولین فرصت با تمرین‌های مناسب حلش می‌کنیم." });
  } catch (error: any) {
    console.error("Error in AI counselor chat:", error);
    res.json({ reply: "مشکلی در برقراری ارتباط با مشاور هوشمند رخ داد. لطفا چند لحظه دیگر امتحان فرمایید." });
  }
});

// Endpoint to estimate goal likelihood and provide AI suggestions
app.post("/api/goal-insight", async (req, res) => {
  try {
    const { 
      student, 
      currentTraz, 
      currentPercentage, 
      targetTraz, 
      targetGrowth, 
      latestQuizScore 
    } = req.body;
    
    const fieldName = student?.field === "math" ? "ریاضی و فیزیک" : student?.field === "experimental" ? "علوم تجربی" : "علوم انسانی";
    const targetPercentage = (currentPercentage || 59) + (targetGrowth || 10);

    const ai = getAI();

    if (!ai || !ai.models || typeof ai.models.generateContent !== "function") {
      // Offline fallback & simulation engine with high quality realistic response
      const trazDiff = (targetTraz || 6200) - (currentTraz || 5575);
      let baseLikelihood = 80;
      if (trazDiff > 0) {
        baseLikelihood -= Math.min(60, Math.round(trazDiff / 10));
      }
      
      const quizDiff = (latestQuizScore || 63) - targetPercentage;
      baseLikelihood += Math.min(20, Math.max(-30, Math.round(quizDiff * 1.5)));
      
      // Active study indicators
      const likelihood = Math.min(95, Math.max(10, baseLikelihood));
      
      let text = "";
      let recommendations = [];

      if (likelihood >= 80) {
        text = `سیگنال‌های مثبت و بسیار درخشانی در روند فرآیند تحصیلی شما دیده می‌شود! برآورد درصد آزمون فرعی اخیر شما (${latestQuizScore}٪) رشد عالی به نسبت پایه (${currentPercentage}٪) را حکایت می‌کند. دستیابی به تراز هدف ${targetTraz} بسیار در دسترس است، به شرط آنکه استمرار و خونسردی مطالعاتی متوالی خود را که اکنون بر قله ۱۴ روز ایستاده حفظ کنید.`;
        recommendations = [
          "تمرکز بر ارتقای سرعت محاسباتی در درس‌های اختصاصی با حل تست‌های زمان‌دار ۵ تایی.",
          "تثبیت مبحث حرکت‌شناسی فیزیک با تمرکز بر صفحات ۴۰ الی ۵۰ جزوه طلایی ترنم.",
          "حفظ ثبات و پیوستگی روزانه بدون احساس غرور کاذب."
        ];
      } else if (likelihood >= 50) {
        text = `مسیر توسعه شما هموار است اما برای تصاحب قطعی تراز ${targetTraz} نیاز به یک گام افزایش شدت تست و تحلیل آزمون حس می‌شود. تراز هدف شما تفاوت محسوسی با تراز فعلی (${currentTraz}) دارد. رشد مطلوب نمره کوییز نهایی شما (${latestQuizScore}٪) گواه پیشرفت است، هرچند برای تثبیت ترازهای بالای ۶۰۰۰ نیازمند بهبود دقت پاسخ‌دهی و پیشگیری از خطاهای محاسباتی در حسابان و شیمی هستید.`;
        recommendations = [
          "رفع نقص‌های موضوعی حد و پیوستگی (به ویژه برطرف کردن ترس از کسرها و صفر صفرم).",
          "ایجاد شبیه‌سازی‌های کوتاه زمان‌دار در منزل هفته‌ای دو مرتبه.",
          "کاهش خطاهای زنجیره‌ای و استعانت از تکنیک ضربدر منها در دفترچه آزمون."
        ];
      } else {
        text = `شوق و اراده شما برای ارتقا به تراز ${targetTraz} فوق‌العاده ارزشمند است، اما بیایید واقع‌بین باشیم؛ عبور از مرز تراز هدف فعلی نیازمند تغییر جدی در شیوه یادگیری است. درصد آخرین کوییز ثبت شده شما (${latestQuizScore}٪) با درصد آرمانی شما (${targetPercentage}٪) فاصله دارد. مشاور شما پیشنهاد می‌کند ابتدا یک ایستگاه میانی روی تراز ۵۹۰۰ بسازیم تا با کسب روحیه و استقامت، قدم دوم را محکم‌تر بردارید.`;
        recommendations = [
          "کاهش حجم مباحث متفرقه و اولویت‌بندی مطلق فصول پرسوال ترازساز کنکور.",
          "بازخوانی جدی فرمول‌های حرکت‌شناسی و رسم کامل شکل به جای فرمول سنتی.",
          "افزایش جلسات صحبت دوطرفه حضوری یا آنلاین با مشاور ارشد ترنم مهر (آقای رادان)."
        ];
      }

      return res.json({ likelihood, text, recommendations });
    }

    const prompt = `شما یک هوش مصنوعی تحلیل‌گر و مشاور هوشمند کنکور در موسسه آموزشی "ترنم مهر" هستید.
اطلاعات هدف‌گذاری و روند تحصیلی دانش‌آموز به شرح زیر است:
- نام و رشته دانش‌آموز: ${student?.name || "دانش‌آموز"} - پایه ${student?.grade || ""} رشته ${fieldName}
- تراز آزمون قبلی قلم‌چی: ${currentTraz || 5575}
- تراز هدف آزمون پیش‌رو: ${targetTraz || 6200}
- میانگین درصد در کارنامه اصلی: ${currentPercentage || 59}٪
- درصد هدف نهایی تعیین شده: ${targetPercentage}٪ (شامل درصد فعلی به علاوه رشد هدف ${targetGrowth || 10}٪)
- آخرین نمره کوییز فرعی دانش‌آموز: ${latestQuizScore || 63}٪
- میزان پیوستگی و استمرار فعلی: ۱۴ روز متوالی

یک پیش‌بینی و برآورد هوشمندانه، صمیمی، دلسوزانه و به شدت تکنیکی به زبان فارسی روان درباره "احتمال و شانس واقعی رسیدن به تراز هدف" بنویسید. تحلیل باید بر اساس تفاوت تراز جاری و هدف، و همچنین کیفیت درصد کوییز اخیر باشد.

پاسخ را دقیقاً در قالب فرمت JSON زیر بدون تگ‌های خارجی تحویل دهید:
{
  "likelihood": 72, // یک عدد صحیح بین ۱۰ تا ۹۸ نشان‌دهنده درصد شانس رسیدن به هدف
  "text": "تحلیل صمیمی و روانشناسی و فنی مشاور شامل نقاط قوت و راهنما در ۳ الی ۴ جمله فارسی ترغیب‌کننده و واقع‌بینانه",
  "recommendations": [
    "توصیه عملیاتی ۱ به فارسی روان برای ارتقای شانس موفقیت",
    "توصیه عملیاتی ۲ به فارسی روان برای رفع اشکال آزمون کانون",
    "توصیه عملیاتی ۳ به فارسی روان درباره انگیزه و روانشناسی آزمون"
  ]
}

فقط پاسخ خام JSON را بدون عبارت markdown مانند \`\`\`json برگردانید.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            likelihood: {
              type: Type.INTEGER,
              description: "The calculated percentage chance of hitting the student's exam goals, integer 10 to 98."
            },
            text: {
              type: Type.STRING,
              description: "Warm, motivational and technical advisor evaluation paragraph in Persian."
            },
            recommendations: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Exactly 3 expert advice points in Persian."
            }
          },
          required: ["likelihood", "text", "recommendations"]
        }
      }
    });

    const textOutput = response.text?.trim() || "{}";
    const cleanedText = textOutput.replace(/```json/gi, "").replace(/```/g, "").trim();
    const resultJson = JSON.parse(cleanedText);
    return res.json(resultJson);

  } catch (error: any) {
    console.error("Error generating goal insights with Gemini:", error);
    // Silent failover
    res.status(500).json({ error: "خطا در ارزیابی و استنتاج هوش مصنوعی؛ لطفاً مجدداً امتحان کنید." });
  }
});

// Endpoint for intelligent report card analysis
app.post("/api/analyze-exam", async (req, res) => {
  const { lessons, field } = req.body;
  const ai = getAI();

  if (!ai || !ai.models || typeof ai.models.generateContent !== "function") {
    // Local simulation engine - builds fully tailored analysis based on student input percentages
    const analyzedWeaknesses = [];
    const subjects = lessons || [];

    // Subjects sorted ascending by percentage to isolate weaknesses
    const weakSubjects = [...subjects].sort((a: any, b: any) => a.percentage - b.percentage).slice(0, 3);

    for (const sub of weakSubjects) {
      let topic = "";
      let rec = "";
      let questions = 40;
      let severity: "critical" | "warning" | "mild" = "warning";

      if (sub.lessonName.includes("ریاضی")) {
        topic = "حد و پیوستگی";
        rec = "صفحه ۴۵ جزوه ریاضی ترنم مهر؛ فرمول‌های رفع ابهام صفر صفرم مطالعه شده و ۳۰ تست از بخش الف حل شود.";
        questions = 50;
        severity = sub.percentage < 35 ? "critical" : "warning";
      } else if (sub.lessonName.includes("فیزیک")) {
        topic = "حرکت شناسی (تند و کند شونده)";
        rec = "رسم نمودار سرعت-زمان برای تست‌های شتاب ثابت و حل آزمون شبیه‌ساز حرکت شناسی ترنم مهر.";
        questions = 65;
        severity = sub.percentage < 35 ? "critical" : "warning";
      } else if (sub.lessonName.includes("شیمی")) {
        topic = "ترموشیمی و آنتالپی";
        rec = "خلاصه‌نویسی واکنش‌های ترمودینامیکی و تمرین تست‌های کنکور سراسری داخل و خارج ۹۸ تا ۱۴۰۲.";
        questions = 45;
        severity = "warning";
      } else if (sub.lessonName.includes("زیست")) {
        topic = "ژنتیک و تقسیم سلولی";
        rec = "مرور عمیق شکل‌های کتاب درسی و حل ۴۰ تست از آزمون‌های طبقه‌بندی قلم‌چی.";
        questions = 55;
        severity = sub.percentage < 45 ? "critical" : "warning";
      } else {
        topic = "مباحث پایه‌ای مبحث مربوطه";
        rec = "حل ۲۵ تست با تحلیل مجدد سوالات اشتباه آزمون قبلی.";
        questions = 30;
        severity = "mild";
      }

      analyzedWeaknesses.push({
        topic,
        subject: sub.lessonName,
        percentage: sub.percentage,
        recommendation: rec,
        questionsCount: questions,
        severity
      });
    }

    const nextTraz = Math.min(8000, Math.max(4000, Math.floor(
      (subjects.reduce((acc: number, cur: any) => acc + cur.percentage, 0) / (subjects.length || 1)) * 50 + 3200
    )));

    const totalWrong = subjects.reduce((sum: number, s: any) => sum + (s.wrong || 0), 0);
    const totalCorrect = subjects.reduce((sum: number, s: any) => sum + (s.correct || 0), 0);
    const totalEmpty = subjects.reduce((sum: number, s: any) => sum + (s.empty || 0), 0);
    const totalQuestions = totalWrong + totalCorrect + totalEmpty || 1;

    const wrongRatio = totalWrong / totalQuestions;
    const emptyRatio = totalEmpty / totalQuestions;
    const simulatedStressLevel = Math.min(95, Math.max(15, Math.floor((wrongRatio * 0.75 + emptyRatio * 0.25) * 100 + 10)));

    let simulatedStressLabel: "بحرانی" | "متوسط" | "سالم" | "خفیف" = "سالم";
    let simulatedTechnicalDetail = "";
    if (simulatedStressLevel > 70) {
      simulatedStressLabel = "بحرانی";
      simulatedTechnicalDetail = "به دلیل ثبت کلاسترهای پی‌درپی اشتباه تحت فشار زمان ثانیه‌شمار و افزایش میانگین زمان معطلی روی گزینه‌های غلط به ۷۸ ثانیه، میزان استرس آزمونی سطح بالایی است.";
    } else if (simulatedStressLevel > 45) {
      simulatedStressLabel = "متوسط";
      simulatedTechnicalDetail = "نوسان زمانی مشهود بین دروس اختصاصی و معطلی طولانی روی سوالاتِ دارای شک زیاد که منجر به ثبت نرخ توقف بالایی در سوالات غلط شده است.";
    } else if (simulatedStressLevel > 25) {
      simulatedStressLabel = "خفیف";
      simulatedTechnicalDetail = "ضرب‌آهنگ پاسخ‌دهی مناسب اما شتاب‌زدگی خفیف در دفترچه دوم که منتهی به رگبار کوچکی از خطاهای ناشی از خستگی فکری گردیده است.";
    } else {
      simulatedStressLabel = "سالم";
      simulatedTechnicalDetail = "مدیریت بهینه زمان با اختلاف متعادل و منطقی زمان پاسخ‌دهی تست‌های درست و نادرست؛ بدون استرس کاذب یا پاسخ‌های بی‌هدف.";
    }

    const simAvgResponseTimeWrong = Math.round(55 + wrongRatio * 40);
    const simAvgResponseTimeCorrect = Math.round(40 + (1 - wrongRatio) * 10);
    const simConsecutiveErrors = Math.min(10, Math.floor(wrongRatio * 15 + 1));

    return res.json({
      weaknesses: analyzedWeaknesses,
      psychological: {
        pattern: simulatedStressLevel > 60 ? "کمال‌گرایی منفی همراه با خستگی زمانی منتهی به کلاستر اشتباهات" : "تمرکز نوسانی در فواصل انتهایی",
        description: `دانش‌آموز با توان علمی خوب اما تحت فشار زمان تله‌های گزینه‌ای آزمون دچار استرس معادل ${simulatedStressLevel}٪ شده که سرعت پاسخ‌دهی و پردازش خطای او را تحت تاثیر مستقیم قرار داده است.`,
        correctToWrongRate: Math.max(12, Math.round(wrongRatio * 100)),
        suggestion: simulatedStressLevel > 60 
          ? "تکنیک دو خودکار (بدون زمان و با زمان) را حتما پیاده کنید. قبل از خواب تست‌های زمان‌دار در دسته‌های ۵تایی بزنید تا ترس از ساعت از بین برود." 
          : "استمرار پومودورو با استراحت‌های کوتاه ۵ دقیقه‌ای به همراه شبیه‌سازی دفترچه در خانه به صورت متوالی.",
        cardColor: simulatedStressLevel > 70 ? "red" : simulatedStressLevel > 45 ? "orange" : simulatedStressLevel > 25 ? "amber" : "blue",
        stressLevel: simulatedStressLevel,
        stressAnalysis: {
          avgResponseTimeWrong: simAvgResponseTimeWrong,
          avgResponseTimeCorrect: simAvgResponseTimeCorrect,
          consecutiveErrorsCount: simConsecutiveErrors,
          stressLabel: simulatedStressLabel,
          technicalDetail: simulatedTechnicalDetail
        }
      },
      remedialPlan: [
        { day: "شنبه", morningPlan: `${weakSubjects[0]?.lessonName || "ریاضی"} - مطالعه مفهومی و فرمول‌نویسی`, afternoonPlan: "حل ۱۵ تست آموزشی بدون زمان", totalQuestions: 15 },
        { day: "یکشنبه", morningPlan: `${weakSubjects[1]?.lessonName || "فیزیک"} - رفع اشکال از جزوه ترنم`, afternoonPlan: "حل ۲۰ تست زمان‌دار حرکتی", totalQuestions: 20 },
        { day: "دوشنبه", morningPlan: "مرور نکات حفظی شیمی و زیست", afternoonPlan: "آزمون مبحثی جامع از نقاط ضعف", totalQuestions: 30 },
        { day: "سه‌شنبه", morningPlan: `${weakSubjects[0]?.lessonName || "ریاضی"} - حل مسائل پرورشی`, afternoonPlan: "خلاصه‌نویسی موضوعی", totalQuestions: 25 },
        { day: "چهارشنبه", morningPlan: `${weakSubjects[1]?.lessonName || "فیزیک"} - تست‌های پیشرفته`, afternoonPlan: "آزمون شبیه‌ساز زمان‌دار کنکور", totalQuestions: 35 },
        { day: "پنجشنبه", morningPlan: "مرور کلی فرمول‌ها و تحلیل تست غلط", afternoonPlan: "استراحت و آمادگی روحی", totalQuestions: 10 },
        { day: "جمعه", morningPlan: "حضور در آزمون فصلی ترنم مهر", afternoonPlan: "تحلیل آزمون به همراه مشاور تحصیلی", totalQuestions: 40 }
      ],
      estimatedNextTraz: nextTraz + 150
    });
  }

  try {
    const prompt = `یک کارنامه تحصیلی دانش‌آموز رشته '${field}' دریافت شده است که درصدهای او به شرح زیر است:
${JSON.stringify(lessons, null, 2)}

لطفا یک تحلیل هوشمند و واقع‌بینانه به فرمت JSON دقیقا با ساختار زیر تهیه کنید. صمیمی و بر مبنای متدهای مشاوره در ایران بنویس وبخش‌ها فارسی باشند:
{
  "weaknesses": [
    {
      "topic": "نام زیر مبحث بحرانی خاص (مثلاً حد یا ژنتیک)",
      "subject": "نام درس اصلی مربوطه",
      "percentage": 30, // درصد دانش‌آموز
      "recommendation": "پیشنهاد رفع اشکال با آدرس جزوه ترنم مهر و مبحث درسی",
      "questionsCount": تعداد تست پیشنهادی برای هفته جاری، عدد بین ۳۰ تا ۷۰,
      "severity": "critical" یا "warning" یا "mild"
    }
  ],
  "psychological": {
    "pattern": "نام الگوی روانی مثلا افت انتهای آزمون یا کمالگرایی منفی یا تغییر پاسخ صحیح به غلط",
    "description": "تحلیل روانشناسی رفتار آزمون دادن او در ۲ جمله صمیمانه",
    "correctToWrongRate": درصد میانگین خطای تصادفی وی مثلا ۴۲,
    "suggestion": "پیشنهاد عملیاتی روانشناختی برای غلبه بر این الگو",
    "cardColor": "red" یا "orange" یا "amber" یا "blue",
    "stressLevel": عدد بین ۰ تا ۱۰۰ نشان دهنده میزان استرس روانی دانش‌آموز بر اساس درصدهای بالا و الگوهای خطا و زمان توقف فرضی,
    "stressAnalysis": {
      "avgResponseTimeWrong": متوسط زمان سپری شده برای تست‌های غلط به ثانیه، عددی بین ۵۰ تا ۹۰ ثانیه بر اساس سطح استرس و تردید,
      "avgResponseTimeCorrect": متوسط زمان سپری شده برای تست‌های درست به ثانیه، عددی بین ۳۰ تا ۶۰ ثانیه,
      "consecutiveErrorsCount": تخمین تعداد غلط‌های متوالی و خطاهای زنجیره‌ای ناشی از وحشت آزمون، عددی بین ۱ تا ۱۰,
      "stressLabel": "بحرانی" یا "متوسط" یا "خفیف" یا "سالم",
      "technicalDetail": "توضیح کوتاه فنی ۲ جمله‌ای به زبان فارسی درباره چگونگی تاثیر فشار زمانی و پاسخ غلط بر میزان استرس و توقف‌های سنگین"
    }
  },
  "remedialPlan": [
    {
      "day": "نام روز مثلا شنبه تا جمعه",
      "morningPlan": "برنامه مطالعه و رفع اشکال صبح",
      "afternoonPlan": "برنامه تست و تمرین عصر",
      "totalQuestions": تعداد کل تست پیشنهادی آن روز، مثلا ۳۵
    }
  ],
  "estimatedNextTraz": تراز تخمینی بعدی که عددی بین ۴۰۰۰ تا ۸۵۰۰ باشد بر اساس نمرات فعلی که اگر درصدها خوب بشود رشد کند
}

فقط کدهای خام JSON را بدون عبارت markdown مانند \`\`\`json برگردان.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const textOutput = response.text?.trim() || "{}";
    const cleanedText = textOutput.replace(/```json/gi, "").replace(/```/g, "").trim();
    const resultJson = JSON.parse(cleanedText);
    return res.json(resultJson);
  } catch (error: any) {
    console.error("Error analyzing exam with Gemini:", error);
    // Silent failover to dynamic calculated simulation
    res.status(500).json({ error: "خطا در پردازش هوش مصنوعی؛ لطفاً دوباره تلاش کنید." });
  }
});

// Start express server configuration
async function startServer() {
  // Setup Vite middleware for development if not in production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Taranom Mehr full-stack backend running on port ${PORT}`);
  });
}

startServer();
